namespace AdventureWorks.MAUI.Resources.Styles;

public partial class AppStyles : ResourceDictionary
{
	public AppStyles()
	{
		InitializeComponent();
	}
}