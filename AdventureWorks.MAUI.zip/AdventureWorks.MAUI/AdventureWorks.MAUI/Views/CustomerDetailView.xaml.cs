namespace AdventureWorks.MAUI.Views;

public partial class CustomerDetailView : ContentPage
{
	public CustomerDetailView()
	{
		InitializeComponent();
	}
}