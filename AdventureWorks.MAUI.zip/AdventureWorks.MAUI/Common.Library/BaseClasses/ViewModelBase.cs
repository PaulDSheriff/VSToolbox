﻿namespace Common.Library;

public class ViewModelBase : CommonBase
{
}
