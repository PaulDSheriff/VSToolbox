﻿namespace Common.Library;

public class EntityBase : CommonBase
{
}
